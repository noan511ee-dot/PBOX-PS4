// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 RafaelNGP
constexpr Column kEnglish = {
    "PBOX Cloud Gaming",                             // AppName
    "PBOX CLOUD GAMING",                             // CloudGaming
    "Signing in...",                                  // SigningIn
    "Getting a sign-in code...",                      // RequestingCode
    "Loading your games...",                          // LoadingGames
    "Sign in to play",                                // SignInTitle
    "On your phone or computer, go to",               // SignInStep1
    "and enter this code",                            // SignInStep2
    "Scan to open the page, then enter the code",     // SignInScan
    "Waiting for you to sign in...",                  // SignInWaiting
    "Jump back in",                                   // JumpBackIn
    "Play",                                           // Play
    "Back",                                           // Back
    "Select",                                         // Select
    "Sign out",                                       // SignOut
    "Cancel",                                         // Cancel
    "Try again",                                      // TryAgain
    "Getting your game ready",                        // GettingReady
    "You're in the queue. Estimated wait: %s",        // InQueue
    "Connecting...",                                  // Connecting
    "Starting the stream...",                         // StartingStream
    "Touchpad: ↓ this menu · ↑ Xbox button",            // MenuGestureHint
    "Stream ended",                                   // StreamEnded
    "Something went wrong",                           // ErrorTitle
    "Signed in as %s",                                // SignedInAs
    "No games to show yet",                           // NoGames
    "By %s",                                          // PublisherBy
    "Settings",                                       // Settings
    "Language",                                       // Language
    "Stream resolution",                              // Resolution
    "Server region",                                  // Region
    "Automatic (%s)",                                 // RegionAuto
    "1080p (Full HD)",                                // Res1080
    "720p (uses less data)",                          // Res720
    "1440p / Best (Auto)",                            // ResBest
    "Resolution and region apply to the next game you start.",  // SettingsNote
    "Change",                                         // Change
    "Adjust",                                         // Adjust
    "Hold to sign out",                               // HoldSignOut
    "Keep holding to sign out (%s)",                  // SigningOutIn
    "Sign-in failed: %s",                             // SignInFailed
    "Sign-in not completed in the browser. Use a personal Microsoft account, complete any security prompts/2FA, and grant access to the app.",  // SignInInteractionRequired
    "Could not load the game list: %s",               // LibraryFailed
    "Could not start the stream: %s",                 // StreamFailed
    "No input for a while: you will be disconnected in %s seconds",  // IdleWarning
    "My games",                                     // YourGames
    "Not available on your account",                  // NotPlayable
    "Game Pass",                                    // TabGamePass
    "Search",                                       // TabSearch
    "Type the name of a game",                      // SearchHint
    "No games found",                               // NoResults
    "%s results",                                   // ResultsCount
    "Space",                                        // KeySpace
    "Delete",                                       // KeyDelete
    "Clear",                                        // KeyClear
    "%s games",                                     // GamesCount
    "Type",                                         // KeyType
    "Trying another region: %s",                    // TryingRegion
    "Available to buy",                              // AvailableToBuy
    "BUY",                                           // BuyBadge
    "Buy this game to play it in the cloud",         // BuyToPlay
    "Buy it on xbox.com or in the Xbox app; it then shows up in My games.", // BuyHint
    "Scan to open the store page",                   // ScanToBuy
    "Search in %s",                                  // SearchIn
    "FREE",                                          // Free
    "Hide",                                          // Hide
    "Show",                                          // Unhide
    "Hidden",                                        // HiddenSection
    "Square shows a game again",                     // HiddenHint
    "Hidden: find it under Hidden, at the end of this tab", // HiddenToast
    "Shown again",                                   // UnhiddenToast
    "Sort: %s",                                      // SortLabel
    "Recent first",                                  // SortRecent
    "A-Z",                                           // SortAZ
    "By console",                                    // SortConsole
    "Sort",                                          // SortHint
    "Free",                                          // FilterFree
    "Lowest price",                                  // FilterCheapest
    "All consoles",                                  // FilterAllConsoles
    "1 game",                                        // OneGame
    "Sections",                                      // Sections
    "Updating the game list...",                     // UpdatingList
    "Game menu",                                     // MenuTitle
    "Statistics",                                    // MenuStats
    "On",                                            // On
    "Off",                                           // Off
    "Stream resolution",                             // MenuResolution
    "Leave game",                                    // MenuLeave
    "Latency",                                       // StatLatency
    "Bitrate",                                       // StatBitrate
    "Frame rate",                                    // StatFrameRate
    "Packet loss",                                   // StatLoss
    "Region",                                        // StatRegion
    "Decoding",                                      // StatDecode
    "The server may keep the current quality",       // ResolutionNote
    "Sharpness",                                     // MenuSharpness
    "Off",                                           // SharpOff
    "Low",                                           // SharpLow
    "Medium",                                        // SharpMedium
    "High",                                          // SharpHigh
    "Stick dead zone",                               // Deadzone
    "Trigger vibration",                             // TriggerRumble
    "Confirm button",                                // ConfirmButton
    "On",                                            // Activated
    "Off",                                           // Deactivated
    "Version %s available",                          // UpdateAvailable
    "Controllers",                                   // Controllers
    "Controller %s connected",                       // PadConnected
    "Controller %s disconnected",                    // PadDisconnected
    "Block smoothing",                               // MenuDeband
    "On screen after",                               // StatOnScreen
    "Connection lost: reconnecting...",              // Reconnecting
    "Reconnected",                                   // Reconnected
    "Light bar",                                     // LightBar
    "Upscaling",                                     // MenuUpscaler
    "AI (Anime4K)",                                  // UpscalerAi
    "Free to play",                                  // FreeToPlay
    "Get it once, free, on xbox.com or in the Xbox app (scan the code with your phone), then press Play.", // FreeHint
    "Scan to get it free",                          // ScanToGet
    "%s is not on your account yet. It is free: scan the code on its page, choose Get, then try again (it can take a minute).", // NoEntitlementFree
    "Your account can't play %s: it is not in your subscription or not bought.", // NoEntitlement
    "My consoles",                                   // TabConsoles
    "On",                                            // ConsoleOn
    "Sleeping",                                      // ConsoleSleeping
    "Off",                                           // ConsoleOff
    "Looking for your consoles...",                  // ConsolesLoading
    "No Xbox found yet",                       // NoConsoles
    "Play your own Xbox here: its screen, games and apps.", // ConsolesHint
    "Waking up your Xbox...",                        // WakingConsole
    "%s did not answer. Check that Remote features are on and the power mode is Sleep, or turn it on, then try again.", // WakeFailed
    "On your Xbox, sign in with this same Microsoft account.", // ConsoleStep1
    "Settings > Devices & connections > Remote features: turn on remote features.", // ConsoleStep2
    "Settings > General > Power options: choose Sleep, so it wakes up by itself.", // ConsoleStep3
    "Scan for Microsoft's help",                     // ScanForHelp
    "Search again",                                  // SearchAgain
    "Xbox button",                                   // MenuXboxButton
    "End the stream",                                // MenuEndStream
    "The stream was ended on the Xbox",               // EndedOnXbox
    "Another device took over the stream",            // EndedByOtherDevice
    "The Xbox was turned off",                        // EndedXboxOff
    "%s got the request but its Remote Play didn't start. Restart it: hold the power button on the console for 10 seconds, turn it back on, then try again.", // StreamingStuck
    "Touchpad: swipe ↓ for the menu, ↑ for the Xbox button", // GestureHint
    "FSR + clean-up",                                // UpscalerFsrClean
    "AI + clean-up",                                 // UpscalerAiClean
    "Auto (%s)",                                     // DebandAuto
    "Update now? The app restarts by itself when it's done.", // UpdatePrompt
    "Update now",                                    // UpdateNow
    "Not now",                                       // NotNow
    "Updates",                                       // Updates
    "Up to date (%s)",                               // UpToDate
    "%s available: update",                          // UpdateReady
    "Checking...",                                   // UpdateChecking
    "Updating to %s",                                // UpdatingTo
    "Downloading... %s",                             // UpdateDownloading
    "Checking the signature...",                     // UpdateVerifying
    "Installing...",                                 // UpdateInstalling
    "Updated. Restarting...",                        // UpdateRestarting
    "PBOX updated: open the app again",             // UpdateReopen
    "Update failed: nothing was changed",            // UpdateFailed
    "Game colour",                                   // LightBarGame
    "Custom colour",                                 // LightBarCustom
    "Light bar colour",                              // LightBarColour
    "Left stick or D-pad: colour    L2 / R2: brightness", // ColourPickerHelp
    "Light",                                         // TriggerLight
    "Medium",                                        // TriggerMedium
    "Strong",                                        // TriggerStrong
    "Max",                                           // TriggerMax
    "Intensity",                                     // TriggerIntensity
    "Frequency",                                     // TriggerFrequency
    "Low",                                           // FrequencyLow
    "High",                                          // FrequencyHigh
    "Press L2 / R2 to feel it: the deeper, the stronger the game would ask", // TriggerTestHelp
    "Level %s",                                      // TriggerLevel
    "Left stick",                                    // StickLeft
    "Right stick",                                   // StickRight
    "Stick position",                                // StickPosition
    "What the game gets",                            // StickGameGets
    "L1 / R1: choose the stick    D-pad ← / →: adjust    Move the sticks to see it", // StickTestHelp
    "Resistance",                                    // TriggerResistance
    "Style",                                         // TriggerStyle
    "Vibration",                                     // StyleVibration
    "Force pulses",                                  // StylePulses
    "Mode",                                          // FilterMode
    "Genre",                                         // FilterGenre
    "Language",                                      // FilterLanguage
    "All modes",                                     // ModeAll
    "Single player",                                 // ModeSingle
    "Online multiplayer",                            // ModeOnlineMulti
    "Online co-op",                                  // ModeOnlineCoop
    "Local / split screen",                          // ModeLocal
    "All genres",                                    // GenreAll
    "Any language",                                  // LanguageAll
    "English",                                       // LanguageNoun
    "Subtitles in %s",                               // LangSubtitles
    "Audio in %s",                                   // LangAudio
    "Game settings",                                 // GameSettings
    "Profile",                                       // Profile
    "Default",                                       // ProfileDefault
    "Custom",                                        // ProfileCustom
    "Reset to default",                              // ResetToDefault
    "Publisher",                                     // FilterPublisher
    "All publishers",                                // PublisherAll
    "Indies & Others",                               // PublisherIndies
    "Friends playing now",                           // FriendsPlayingNow
    "Microphone",                                    // MenuMicrophone
    "Muted",                                         // MicMuted
    "Active",                                        // MicActive
    "Audio output",                                  // MenuAudioOutput
    "TV",                                            // AudioRouteTv
    "DualSense Speaker",                             // AudioRoutePad
    "Report a problem",                              // ReportProblem
    "Scan it with your phone: GitHub's bug form opens, filled in. You review it before sending it.", // ReportScan
    "It includes the app's version, the error and lines of its log, without personal data.", // ReportIncludes
    "PBOX closed unexpectedly last time",           // CrashedLastTime
    "Sign-in country",                                // LoginCountry
    "Off (this console's)",                           // LoginCountryOff
    "Sign in as another country",                     // TryOtherCountry
    "xCloud will be told the sign-in comes from the chosen country. Microsoft doesn't allow this: use it at your own risk. Games may then come from servers far away, with more delay. You can change it later in Settings.", // LoginCountryWarning
    "xCloud refused the sign-in. Cloud gaming may not be offered in your country, or the account may not have a Game Pass plan with cloud gaming.", // RegionRefused
    "xCloud refused the sign-in, even as %s. The account probably doesn't have a Game Pass plan with cloud gaming.", // RegionRefusedAs
    "Brazil",                                         // CountryBR
    "Japan",                                          // CountryJP
    "South Korea",                                    // CountryKR
    "Poland",                                         // CountryPL
    "United States",                                  // CountryUS
    "Secure connections were refused because the PS5's date and time look wrong (it says %s). Set them in Settings > System > Date and Time, then try again.", // ClockWrong
    "A secure connection was refused: something on the network (a DNS server, proxy or filter) is answering for Microsoft's sites. Try without it, then try again.", // ConnectionIntercepted
    "PS5 date and time look wrong (%s): some content can't load. Set them in Settings > System > Date and Time.", // ClockWrongNotice
    "Your sign-in couldn't be saved on the console, so it will be asked again next time. Please report it (Settings > △).", // SignInNotSaved
    "Estimated wait: %s s", // QueueSeconds
    "Estimated wait: %s min", // QueueMinutes
    "Frame output: 60 / 120 Hz (VRR)", // HighRefresh
    "120 Hz in games", // HighRefreshOn
    "Unstable connection", // ConnectionUnstable
    "Session: %s", // SessionSummary
    "Maximum bitrate", // BitrateCap
    "Automatic", // BitrateAuto
    "Game volume", // GameVolume
    "Keyboard: F12 this menu · Home Xbox button", // MenuKeyHint
    "Mouse & keyboard", // FilterMouseKeyboard
    "Mouse and keyboard", // MouseKeyboardSupport
    "Keyboard and mouse: player %s", // KeyboardPlayer
    "You're in the queue.", // InQueueNoEstimate
    "Keyboard keys", // KeyboardKeys
    "D-pad", // DPad
    "Press a key or mouse button", // PressKey
    "%s is kept by the app", // KeyReserved
    "Change", // ChangeKey
    "Clear", // ClearKey
    "The mouse moves the right stick and a wheel notch presses Triangle. F12 (menu), Home (Xbox button) and 1-4 (player) are kept by the app.", // KeysHelp
    "Gyro aiming", // Gyro
    "Always", // GyroAlways
    "While aiming (L2)", // GyroAiming
    "Gyro intensity", // GyroIntensity
    "Secure connections were refused because this computer's date and time look wrong (it says %s). Correct them in the system's settings, then try again.", // ClockWrongPc
    "This computer's date and time look wrong (%s): some content can't load. Correct them in the system's settings.", // ClockWrongNoticePc
    "Off (this computer's)", // LoginCountryOffPc
    "Open in the browser", // OpenInBrowser
    "%s available: download", // UpdateReadyPc
    "Menu: START + BACK or F12 · Xbox button: Guide or Home", // GestureHintButtons
    "START + BACK or F12: this menu · Guide or Home: Xbox button", // MenuButtonHint
    "Display mode", // DisplayMode
    "Window", // DisplayWindow
    "Fullscreen", // DisplayFullscreen
    "Quit PBOX?", // QuitTitle
    "Quit", // QuitConfirm
    "Controller buttons", // ControllerButtons
    "Press the button for %s", // PadPressButton
    "Missing a button: %s. Give each one a button, or reset or discard the changes.", // PadMissing
    "Discard changes", // DiscardChanges
    "Only the game sees this: the app's menus keep the buttons as they are. Picking a button used by another swaps the two.", // PadHelp
    "Plan", // FilterPlan
    "My plan", // PlanMine
    "All plans", // PlanAll
    "Included with Game Pass %s", // IncludedWithPlan
    "Touchpad as mouse", // TouchpadMouse
    "Favourites", // Favorites
    "Add to favourites", // AddFavorite
    "Remove from favourites", // RemoveFavorite
    "Added to favourites", // AddedToFavorites
    "Removed from favourites", // RemovedFromFavorites
    "Game language", // GameLanguage
    "Monthly cloud gaming limit reached", // MonthlyLimitExceeded
    "Playtime remaining", // PlaytimeRemaining
    "%s h remaining", // HoursRemaining
    "Less than 2 h remaining", // PlaytimeWarning
    "Trigger profile", // TriggerProfile
    "Standard", // TriggerProfileStd
    "Shooter (Hair Trigger)", // TriggerProfileShooter
    "Racing (ABS)", // TriggerProfileRacing
    "Storage %s is not writable: sign-in and settings will not be saved", // StorageNotWritable
    "FTP: run 'chmod 777 %s' or delete the folder and relaunch", // StorageFixHint
    "Customize indicators",                           // StatsCustomize
    "FPS & Resolution",                               // StatsIndicatorFps
    "Bitrate",                                        // StatsIndicatorBitrate
    "Latency (RTT)",                                  // StatsIndicatorLatency
    "Packet loss",                                    // StatsIndicatorLoss
    "Frametime graph",                                // StatsIndicatorGraph
    "Decode & display latency",                       // StatsIndicatorDelay
    "Video quality (QP)",                             // StatsIndicatorQp
    "Microphone status",                              // StatsIndicatorMic
    "Scan the QR code on your phone to resolve this with Microsoft, then press Cross to try again",  // ScanQrToResolve
    "Get Free",                                       // ClaimFree
    "Claiming free license...",                       // Claiming
    "Game added to your account!",                    // ClaimSuccess
    "Failed to claim free game: %s",                  // ClaimFailed
    "This game is not free in the store",             // ProductNotFree
    "Free game. Press Cross to add to your account and start playing",  // FreeAcquireHint
    "DNS lookup failed for Microsoft servers. If you are blocking Sony updates on PS5, make sure you are running NanoDNS with Primary DNS set to your local IP to keep internet access.", // DnsBlockedNanoDns
    "This Microsoft account has no Xbox profile yet. Sign in to xbox.com on your phone or PC to set up your Gamertag, then try again.", // XboxProfileMissing
    "Queue ready! Starting game...",                  // QueueReadyAlert
    "Queue ready chime",                              // QueueReadyNotification
    "Played: %s",                                     // PlaytimePlayed
    "Refresh",                                        // RefreshLibrary
    "Refreshing library...",                          // RefreshingLibrary
    "This Xbox account is suspended or banned. Visit enforcement.xbox.com for details.", // XboxAccountBanned
    "Xbox Live is not offered in this account's country or region.", // XboxRegionNotSupported
    "Age verification or terms acceptance is required. Sign in to xbox.com in a browser, then try again.", // XboxAdultVerificationRequired
    "Child account: an adult must add this account to a Microsoft family at account.microsoft.com/family.", // XboxChildAccountFamily
    "Check my sign-in",                               // CheckSignIn
    "Run check",                                      // RunCheck
    "Network test",                                   // NetworkTest
    "Run test",                                       // RunTest
    "Achievements",                                   // Achievements
    "No achievements",                                // NoAchievements
    "Locked",                                         // AchievementLocked
    "Secret achievement",                             // SecretAchievement
    "Wishlist",                                       // Wishlist
    "Add to wishlist",                                // AddWishlist
    "Remove from wishlist",                           // RemoveWishlist
    "Added to wishlist",                              // AddedToWishlist
    "Removed from wishlist",                          // RemovedFromWishlist
    "%s is on sale!",                                 // WishlistOnSale
    "%s joined Game Pass!",                           // WishlistInGamePass
    "Support the project",                            // SupportProject
    "Support PBOX Development",                      // SupportTitle
    "PBOX is an open-source project passionately maintained to bring the best Xbox Cloud Gaming experience to PlayStation 5. If you enjoy the app and would like to support ongoing development, frequent updates and new features, consider buying me a coffee on Ko-Fi!", // SupportMessage
    "Ko-fi",                                          // SupportKoFi
    "Scan with your phone to support",                // ScanToDonate
    "Test sound",                                     // TestSound
    "Wishlist is empty",                              // WishlistEmpty
    // Loading tips
    "Touchpad: swipe ↓ (or Touchpad + Options) for the menu, ↑ for the Xbox button", // TipTouchpadMenu
    "USB keyboard and mouse plugged into the console are supported in enabled cloud games", // TipKeyboardMouse
    "Claim free games, trials, and discover store promotions directly from the app library", // TipFreeStore
    "Encountered an issue? Open Bug Report to scan a QR code with auto-attached console logs", // TipBugReportQr
    "Enjoying the project? Support future development via Ko-fi in the Settings tab!", // TipSupportKofi
    "Enable 120 Hz display output in Settings for reduced frame latency and smoother response", // Tip120HzVideo
    "Calibrate DualSense stick dead zones in Settings to eliminate stick drift and improve precision", // TipAnalogDeadzone
    "Use the DualSense built-in microphone for party and multiplayer game voice chat", // TipDualSenseMic
    "In keyboard and mouse supported games, use the DualSense touchpad surface as a mouse pointer", // TipTouchpadMouse
    "Enable gyro aiming in Settings to fine-tune your weapon aim with DualSense motion sensors", // TipGyroAiming
    "AMD FSR upscaling and sharpness filters enhance visual clarity and details during streaming", // TipFSRUpscaling
    "Adjust the streaming bitrate cap in Settings up to 45 Mbps for pristine visual quality", // TipCustomBitrate
    "Xbox achievements unlock automatically as native PlayStation 5 trophies while you play", // TipNativeTrophies
    "Toggle native trophy tracking on or off per game from the game details screen", // TipPerGameTrophies
    "Open your phone or PC browser to http://[console-ip]:8080 to access the SmartGlass WebUI", // TipSmartGlassWebUI
    "Claim free game licenses and demos directly in 1 click without leaving the application", // TipClaimFreeStore
    "Customize and remap controller buttons individually per game in the Settings menu", // TipButtonRemap
    "Your library loads instantly from persistent local cache without boot loading screens", // TipInstantResume
    "Swipe down on the touchpad during gameplay to adjust volume, bitrate, and stream settings", // TipInGameMenu
    "Background delta sync keeps your catalog and shelf lists updated automatically", // TipBackgroundSync
    // Settings descriptions
    "Changes the language of the application interface and the preferred audio and subtitles in cloud games", // SettingDescLanguage
    "Sets the maximum stream tier (1080p, 720p, or Best available). Best can upscale to a 4K display; the cloud stream itself may remain 1080p or 1440p. Takes effect on the next launch", // SettingDescResolution
    "Selects the Microsoft datacenter region for streaming (Automatic or specific regions). Takes effect on the next launch", // SettingDescRegion
    "Adjusts the inner dead zone of DualSense analog sticks to prevent stick drift and unintended movement", // SettingDescDeadzone
    "Enables or disables impulse trigger vibration emulation on DualSense L2 and R2 adaptive triggers", // SettingDescTriggerRumble
    "Toggles the confirm and back button layout between Cross (Western style) and Circle (Japanese style)", // SettingDescConfirmButton
    "Configures the light bar color and behavior of your DualSense controller during browsing and gameplay", // SettingDescLightBar
    "Checks for and automatically installs official app updates directly on your console without needing a PC", // SettingDescUpdates
    "Allows signing in to your Xbox account via a different geographic region to access alternative catalogs", // SettingDescLoginCountry
    "Selects 60 Hz or 120 Hz output when supported; this controls output pacing, not the cloud server's native FPS", // SettingDescHighRefresh
    "Sets the maximum bandwidth limit for video streaming, ensuring higher visual fidelity or saving network data", // SettingDescBitrateCap
    "Adjusts the master audio volume level played during game streaming sessions", // SettingDescGameVolume
    "Maps USB or Bluetooth keyboard keys to the corresponding Xbox controller buttons during gameplay", // SettingDescKeyboardKeys
    "Toggles between windowed and fullscreen display mode on supported desktop platforms", // SettingDescDisplayMode
    "Opens the response test and calibration screen for all buttons and axes on your connected controller", // SettingDescControllerButtons
    "Enables DualSense motion sensors to assist with analog aiming in shooter and action games", // SettingDescGyro
    "Plays a distinctive chime when your wait in the xCloud queue finishes and your game is ready", // SettingDescQueueReady
    "Runs a complete diagnostic on your Xbox Live sign-in, validating access tokens, profile, and subscriptions", // SettingDescCheckSignIn
    "Measures ping (RTT) and jitter to cloud gaming datacenters across multiple global regions", // SettingDescNetworkTest
    "Displays a QR Code to support the developer via Ko-fi and help keep the project actively maintained", // SettingDescSupportProject
    "What's New",                                     // WhatsNew
    "What's New",                                     // WhatsNewTitle
    "Controller speaker",                             // PadSpeakerVolume
    "Mute",                                           // Mute
    "Web Control",                                    // WebControlTitle
    "Connect from your phone",                        // WebControlSubtitle
    "Connect to the same Wi-Fi to type search, remap buttons, use your phone as a virtual controller, report issues or view logs.", // WebControlDesc
    "Video Decoder",                                  // VideoDecoder
    "Hardware (Recommended)",                         // VideoDecoderHw
    "Software (CPU)",                                 // VideoDecoderSw
    "Selects hardware decoding (libSceVideodec2 on PS5, HWAccel on Desktop) or CPU software decoding", // SettingDescVideoDecoder
    "Audio-to-Haptics",                               // AudioHaptics
    "Converts low-frequency game audio into DualSense haptic rumble kicks", // SettingDescAudioHaptics
    "Touchpad shortcuts",                             // TouchpadShortcuts
    "Configures swipe gestures and left/right click actions on the DualSense touchpad", // SettingDescTouchpadShortcuts
    "Swipe Up (↑)",                                   // TouchpadSwipeUp
    "Swipe Down (↓)",                                 // TouchpadSwipeDown
    "Swipe Left (←)",                                 // TouchpadSwipeLeft
    "Swipe Right (→)",                                // TouchpadSwipeRight
    "Left Click",                                     // TouchpadClickLeft
    "Right Click",                                    // TouchpadClickRight
    "Disabled",                                       // TouchpadActNone
    "In-game menu",                                   // TouchpadActGameMenu
    "Xbox button",                                    // TouchpadActXboxButton
    "Toggle stats",                                   // TouchpadActToggleStats
    "Mute/unmute mic",                                // TouchpadActToggleMic
    "Cycle gyro mode",                                // TouchpadActCycleGyro
    "Cycle trigger profile",                          // TouchpadActCycleTrigger
    "Touchpad + Options always opens the in-game menu", // TouchpadHelp
    "Restore default settings",                       // ResetSettings
    "Restores all settings to factory defaults. Hold Cross for 5 seconds to confirm.", // SettingDescResetSettings
    "Settings restored to factory defaults.",         // SettingsResetNotice
    "Hold to reset",                                  // HoldToReset
    "Library is already up to date",                  // LibraryUpToDate
    "Library updated (%s new games)",                 // LibraryUpdatedCount
    "Offline mode",                                   // OfflineMode
    "Preview features (xCloud)",                      // PreviewFeatures
    "Enables preview client features and ad-supported Free-to-Play cloud streaming for accounts without Game Pass.", // SettingDescPreviewFeatures
    "Requires Xbox Game Pass Ultimate for cloud streaming", // GamePassRequired
    "In queue (wait time indeterminate • waiting for %s)", // InQueueIndeterminate
    "In queue (estimated wait: %s • waiting for %s)", // InQueueEstimated
    "To stream free-to-play games beyond Fortnite without Game Pass, enable 'Preview Features' in app Settings and on xbox.com/play.", // F2pPreviewRequiredDesc
    "This account needs to enable 'Preview Features' in its profile on xbox.com/play to unlock ad-supported free-to-play streaming.", // F2pPreviewAccountNeededDesc
    "Player",                                    // MenuPlayer
    "Your Xbox cloud gaming time has run out, so the Xbox service ended the session. Since November 2026, Xbox limits cloud play each month: 15 h with Game Pass Ultimate, 10 h with Premium and 5 h with Essential. To get more time, see your options at xbox.com, or new hours come next month.", // CloudTimeUp
    "The stream ended after a while without input", // EndedIdle
    "%s left", // CloudTimeLeft
    "of %s", // CloudTimeOf
    "Unlimited cloud time", // CloudTimeUnlimited
    "%s of your Xbox cloud gaming time left this month", // CloudTimeWarn
    "Sync Trophies",                                  // SyncTrophies
    "Synchronizes all Xbox achievements from your account and awards matching trophies to your PlayStation profile.", // SettingDescSyncTrophies
    "Sync",                                           // RunSyncTrophies
    "Sync complete: %s trophy(ies) across %s title(s) awarded to your profile!", // TrophiesSyncedToast
    "Trophy Sync Warning",                            // TrophiesDisclaimerTitle
    "Enabling trophy conversion adds trophies directly to your PlayStation profile. If you connect this account to PlayStation Network, syncing may risk an account ban. Only enable this on an offline/local profile, or if you do not plan to connect to PSN.", // TrophiesDisclaimerBody
    "I understand",                                   // TrophiesDisclaimerAware
    "Cancel",                                         // TrophiesDisclaimerCancel
    "Remove Synced Trophies",                         // RemoveTrophies
    "Removes all trophies added by PBOX from this local profile, eliminating ban risk. You can re-sync them anytime from your Xbox account.", // SettingDescRemoveTrophies
    "Remove Synced Trophies?",                        // RemoveTrophiesConfirmTitle
    "This will delete local trophy packages added by PBOX for this profile. Your achievements remain safe on your Microsoft/Xbox account.", // RemoveTrophiesConfirmBody
    "Remove",                                         // RemoveTrophiesConfirm
    "Removed %s trophy title(s) from this profile.",  // TrophiesRemovedToast
    "Syncing achievements...",                        // SyncingTrophies
};
