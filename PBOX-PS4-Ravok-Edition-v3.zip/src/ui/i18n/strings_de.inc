// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 RafaelNGP
constexpr Column kGerman = {
    "PBOX Cloud Gaming",
    "PBOX CLOUD GAMING",
    "Anmeldung läuft...",
    "Anmeldecode wird abgerufen...",
    "Deine Spiele werden geladen...",
    "Zum Spielen anmelden",
    "Rufe auf deinem Handy oder Computer",
    "auf und gib diesen Code ein",
    "Scannen, um die Seite zu öffnen, dann den Code eingeben",
    "Warte auf deine Anmeldung...",
    "Weiterspielen",
    "Spielen",
    "Zurück",
    "Auswählen",
    "Abmelden",
    "Abbrechen",
    "Erneut versuchen",
    "Dein Spiel wird vorbereitet",
    "Du bist in der Warteschlange. Geschätzte Wartezeit: %s",
    "Verbindung wird hergestellt...",
    "Streaming wird gestartet...",
    "Touchpad: ↓ dieses Menü · ↑ Xbox-Taste",
    "Streaming beendet",
    "Etwas ist schiefgelaufen",
    "Angemeldet als %s",
    "Noch keine Spiele vorhanden",
    "Von %s",
    "Einstellungen",
    "Sprache",
    "Streaming-Auflösung",
    "Serverregion",
    "Automatisch (%s)",
    "1080p (Full HD)",
    "720p (verbraucht weniger Daten)",
    "Beste (Auto)",
    "Auflösung und Region gelten ab dem nächsten gestarteten Spiel.",
    "Ändern",
    "Anpassen",
    "Halten zum Abmelden",
    "Weiter halten zum Abmelden (%s)",
    "Anmeldung fehlgeschlagen: %s",
    "Die Anmeldung im Browser wurde nicht abgeschlossen. Verwende ein persönliches Microsoft-Konto, schließe Sicherheitsabfragen/2FA ab und gewähre Zugriff.",
    "Die Spieleliste konnte nicht geladen werden: %s",
    "Das Streaming konnte nicht gestartet werden: %s",
    "Keine Aktivität: Die Verbindung wird in %s Sekunden getrennt",
    "Meine Spiele",
    "Für dein Konto nicht verfügbar",
    "Game Pass",
    "Suchen",
    "Gib den Namen eines Spiels ein",
    "Keine Spiele gefunden",
    "%s Ergebnisse",
    "Leerzeichen",
    "Löschen",
    "Leeren",
    "%s Spiele",
    "Tippen",
    "Andere Region wird versucht: %s",
    "Zum Kaufen verfügbar",
    "KAUFEN",
    "Kaufe dieses Spiel, um es in der Cloud zu spielen",
    "Kaufe es auf xbox.com oder in der Xbox-App; danach erscheint es unter Meine Spiele.",
    "Scannen, um die Store-Seite zu öffnen",
    "Suchen in %s",
    "KOSTENLOS",
    "Ausblenden",
    "Einblenden",
    "Ausgeblendet",
    "\xE2\x96\xA1 blendet ein Spiel wieder ein",
    "Ausgeblendet: unter Ausgeblendet, am Ende dieses Tabs",
    "Wieder sichtbar",
    "Sortieren: %s",
    "Zuletzt gespielt",
    "A-Z",
    "Nach Konsole",
    "Sortieren",
    "Kostenlos",
    "Niedrigster Preis",
    "Alle Konsolen",
    "1 Spiel",
    "Abschnitte",
    "Spieleliste wird aktualisiert...",
    "Spielmenü",
    "Statistiken",
    "An",
    "Aus",
    "Stream-Auflösung",
    "Spiel verlassen",
    "Latenz",
    "Bitrate",
    "Bilder pro Sekunde",
    "Paketverlust",
    "Region",
    "Dekodierung",
    "Der Server behält eventuell die aktuelle Qualität bei",
    "Schärfe",
    "Aus",
    "Niedrig",
    "Mittel",
    "Hoch",
    "Stick-Totzone",
    "Trigger-Vibration",
    "Bestätigungstaste",
    "An",
    "Aus",
    "Version %s verfügbar",
    "Controller",
    "Controller %s verbunden",
    "Controller %s getrennt",
    "Blockglättung",
    "Auf dem Bildschirm nach",
    "Verbindung verloren: neu verbinden...",
    "Wieder verbunden",
    "Lichtleiste",
    "Hochskalierung",
    "KI (Anime4K)",
    "Free-to-play",
    "Einmal kostenlos auf xbox.com oder in der Xbox-App holen (Code mit dem Handy scannen), dann Spielen drücken.",
    "Scannen, um es kostenlos zu holen",
    "%s ist noch nicht in deinem Konto. Es ist kostenlos: Code auf seiner Seite scannen, Abrufen wählen und erneut versuchen (kann eine Minute dauern).",
    "Dein Konto kann %s nicht spielen: nicht in deinem Abo oder nicht gekauft.",
    "Meine Konsolen",
    "An",
    "Im Standby",
    "Aus",
    "Deine Konsolen werden gesucht...",
    "Noch keine Xbox gefunden",
    "Spiele hier auf deiner eigenen Xbox: ihr Bildschirm, ihre Spiele und Apps.",
    "Deine Xbox wird geweckt...",
    "%s hat nicht geantwortet. Prüfe, ob die Remotefunktionen aktiv sind und der Energiemodus Ruhezustand ist, oder schalte sie ein und versuche es erneut.",
    "Melde dich auf deiner Xbox mit genau diesem Microsoft-Konto an.",
    "Einstellungen > Geräte & Verbindungen > Remotefunktionen: Remotefunktionen aktivieren.",
    "Einstellungen > Allgemein > Energieoptionen: Ruhezustand wählen, damit sie von selbst aufwacht.",
    "Scannen für die Hilfe von Microsoft",
    "Erneut suchen",
    "Xbox-Taste",
    "Streaming beenden",
    "Das Streaming wurde auf der Xbox beendet",
    "Ein anderes Gerät hat das Streaming übernommen",
    "Die Xbox wurde ausgeschaltet",
    "%s hat die Anfrage erhalten, aber Remote Play ist nicht gestartet. Starte sie neu: Halte die Ein/Aus-Taste der Konsole 10 Sekunden gedrückt, schalte sie wieder ein und versuche es erneut.",
    "Touchpad: ↓ wischen für das Menü, ↑ für die Xbox-Taste",
    "FSR + Bereinigung",
    "KI + Bereinigung",
    "Auto (%s)",
    "Jetzt aktualisieren? Die App startet danach von selbst neu.",
    "Jetzt aktualisieren",
    "Nicht jetzt",
    "Updates",
    "Aktuell (%s)",
    "%s verfügbar: aktualisieren",
    "Wird geprüft...",
    "Aktualisierung auf %s",
    "Wird geladen... %s",
    "Signatur wird geprüft...",
    "Wird installiert...",
    "Aktualisiert. Neustart...",
    "PBOX aktualisiert: App erneut öffnen",
    "Update fehlgeschlagen: nichts wurde geändert",
    "Farbe des Spiels",
    "Eigene Farbe",
    "Farbe der Lichtleiste",
    "Linker Stick oder Steuerkreuz: Farbe    L2 / R2: Helligkeit",
    "Leicht",
    "Mittel",
    "Stark",
    "Maximal",
    "Stärke",
    "Frequenz",
    "Tief",
    "Hoch",
    "L2 / R2 drücken zum Fühlen: je tiefer, desto stärker würde es das Spiel verlangen",
    "Stufe %s",
    "Linker Stick",
    "Rechter Stick",
    "Tatsächliche Position",
    "Was das Spiel bekommt",
    "L1 / R1: Stick wählen    Steuerkreuz ← / →: einstellen    Sticks bewegen zum Sehen",
    "Widerstand",
    "Stil",
    "Vibration",
    "Kraftimpulse",
    "Modus",
    "Genre",
    "Sprache",
    "Alle Modi",
    "Einzelspieler",
    "Online-Mehrspieler",
    "Online-Koop",
    "Lokal / geteilter Bildschirm",
    "Alle Genres",
    "Alle Sprachen",
    "Deutsch",
    "Untertitel: %s",
    "Sprachausgabe: %s",
    "Spieleinstellungen",
    "Profil",
    "Standard",
    "Benutzerdefiniert",
    "Auf Standard zurücksetzen",
    "Publisher",
    "Alle Publisher",
    "Indies & Andere",
    "Freunde spielen jetzt",
    "Mikrofon",
    "Stumm",
    "Aktiv",
    "Audioausgabe",
    "TV",
    "Controller-Lautsprecher",
    "Problem melden",
    "Mit dem Handy scannen: Das Fehlerformular auf GitHub öffnet sich ausgefüllt. Du prüfst es vor dem Senden.",
    "Enthalten sind die App-Version, der Fehler und Zeilen des Logs, ohne persönliche Daten.",
    "PBOX wurde beim letzten Mal unerwartet beendet",
    "Anmeldeland",
    "Aus (das der Konsole)",
    "Als anderes Land anmelden",
    "xCloud wird mitgeteilt, dass die Anmeldung aus dem gewählten Land kommt. Microsoft erlaubt das nicht: Nutzung auf eigenes Risiko. Spiele kommen dann eventuell von weit entfernten Servern, mit mehr Verzögerung. Später in den Einstellungen änderbar.",
    "xCloud hat die Anmeldung abgelehnt. Cloud Gaming wird in deinem Land vielleicht nicht angeboten, oder das Konto hat kein Game-Pass-Abo mit Cloud Gaming.",
    "xCloud hat die Anmeldung abgelehnt, auch mit %s. Das Konto hat wahrscheinlich kein Game-Pass-Abo mit Cloud Gaming.",
    "Brasilien",
    "Japan",
    "Südkorea",
    "Polen",
    "USA",
    "Sichere Verbindungen wurden abgelehnt, weil Datum und Uhrzeit der PS5 falsch zu sein scheinen (sie zeigt %s). Stelle sie unter Einstellungen > System > Datum und Uhrzeit ein und versuche es erneut.",
    "Eine sichere Verbindung wurde abgelehnt: Etwas im Netzwerk (DNS-Server, Proxy oder Filter) antwortet anstelle der Microsoft-Seiten. Versuche es ohne und dann erneut.",
    "Datum und Uhrzeit der PS5 scheinen falsch zu sein (%s): Einige Inhalte laden nicht. Stelle sie unter Einstellungen > System > Datum und Uhrzeit ein.",
    "Die Anmeldung konnte nicht auf der Konsole gespeichert werden und wird beim nächsten Mal erneut abgefragt. Bitte melde das (Einstellungen > △).",
    "Geschätzte Wartezeit: %s s", // QueueSeconds
    "Geschätzte Wartezeit: %s Min.", // QueueMinutes
    "120-Hz-Ausgabe (VRR)", // HighRefresh
    "An (in Spielen)", // HighRefreshOn
    "Instabile Verbindung", // ConnectionUnstable
    "Sitzung: %s", // SessionSummary
    "Maximale Bitrate", // BitrateCap
    "Automatisch", // BitrateAuto
    "Spiellautstärke", // GameVolume
    "Tastatur: F12 dieses Menü · Pos1 Xbox-Taste", // MenuKeyHint
    "Maus & Tastatur", // FilterMouseKeyboard
    "Maus und Tastatur", // MouseKeyboardSupport
    "Tastatur und Maus: Spieler %s", // KeyboardPlayer
    "Du bist in der Warteschlange.", // InQueueNoEstimate
    "Tastaturbelegung", // KeyboardKeys
    "Steuerkreuz", // DPad
    "Drücke eine Taste oder Maustaste", // PressKey
    "%s ist für die App reserviert", // KeyReserved
    "Ändern", // ChangeKey
    "Löschen", // ClearKey
    "Die Maus bewegt den rechten Stick, jede Rasterstufe des Mausrads drückt Dreieck. F12 (Menü), Pos1 (Xbox-Taste) und 1-4 (Spieler) sind für die App reserviert.", // KeysHelp
    "Gyro-Zielen", // Gyro
    "Immer", // GyroAlways
    "Beim Zielen (L2)", // GyroAiming
    "Gyro-Stärke", // GyroIntensity
    "Sichere Verbindungen wurden abgelehnt, weil Datum und Uhrzeit dieses Computers falsch zu sein scheinen (er zeigt %s). Korrigiere sie in den Systemeinstellungen und versuche es erneut.", // ClockWrongPc
    "Datum und Uhrzeit dieses Computers scheinen falsch zu sein (%s): Einige Inhalte laden nicht. Korrigiere sie in den Systemeinstellungen.", // ClockWrongNoticePc
    "Aus (das des Computers)", // LoginCountryOffPc
    "Im Browser öffnen", // OpenInBrowser
    "%s verfügbar: herunterladen", // UpdateReadyPc
    "Menü: START + BACK oder F12 · Xbox-Taste: Guide oder Pos1", // GestureHintButtons
    "START + BACK oder F12: dieses Menü · Guide oder Pos1: Xbox-Taste", // MenuButtonHint
    "Anzeigemodus", // DisplayMode
    "Fenster", // DisplayWindow
    "Vollbild", // DisplayFullscreen
    "PBOX beenden?", // QuitTitle
    "Beenden", // QuitConfirm
    "Controller-Tasten", // ControllerButtons
    "Drücke die Taste für %s", // PadPressButton
    "Ohne Taste: %s. Weise jeder Funktion eine zu, oder setze zurück bzw. verwirf die Änderungen.", // PadMissing
    "Änderungen verwerfen", // DiscardChanges
    "Gilt nur im Spiel: Die Menüs der App nutzen die Tasten, wie sie sind. Eine schon belegte Taste zu wählen tauscht die beiden.", // PadHelp
    "Abo", // FilterPlan
    "Mein Abo", // PlanMine
    "Alle Abos", // PlanAll
    "In Game Pass %s enthalten", // IncludedWithPlan
    "Touchpad als Maus", // TouchpadMouse
    "Favoriten", // Favorites
    "Zu Favoriten hinzufügen", // AddFavorite
    "Aus Favoriten entfernen", // RemoveFavorite
    "Zu Favoriten hinzugefügt", // AddedToFavorites
    "Aus Favoriten entfernt", // RemovedFromFavorites
    "Spiel-Sprache", // GameLanguage
    "Monatliches Cloud-Gaming-Limit erreicht", // MonthlyLimitExceeded
    "Verbleibende Spielzeit", // PlaytimeRemaining
    "%s Std. verbleibend", // HoursRemaining
    "Weniger als 2 Std. verbleibend", // PlaytimeWarning
    "Trigger-Profil", // TriggerProfile
    "Standard", // TriggerProfileStd
    "Shooter (Hair Trigger)", // TriggerProfileShooter
    "Rennen (ABS)", // TriggerProfileRacing
    "Speicher %s ist schreibgeschützt: Anmeldung und Einstellungen werden nicht gespeichert", // StorageNotWritable
    "FTP: 'chmod 777 %s' ausführen oder Ordner löschen und neu starten", // StorageFixHint
    "Indikatoren anpassen",                           // StatsCustomize
    "FPS und Auflösung",                              // StatsIndicatorFps
    "Bitrate",                                        // StatsIndicatorBitrate
    "Latenz (RTT)",                                   // StatsIndicatorLatency
    "Paketverlust",                                   // StatsIndicatorLoss
    "Frametime-Diagramm",                             // StatsIndicatorGraph
    "Dekodier- und Anzeigelatenz",                    // StatsIndicatorDelay
    "Videoqualität (QP)",                             // StatsIndicatorQp
    "Mikrofonstatus",                                 // StatsIndicatorMic
    "Scannen Sie den QR-Code mit dem Smartphone, um dies bei Microsoft zu beheben, und drücken Sie dann Kreuz zum Wiederholen",  // ScanQrToResolve
    "Kostenlos holen",                                // ClaimFree
    "Kostenlose Lizenz wird angefordert...",          // Claiming
    "Spiel erfolgreich zu Ihrem Konto hinzugefügt!", // ClaimSuccess
    "Kostenloses Spiel konnte nicht angefordert werden: %s",  // ClaimFailed
    "Dieses Spiel ist im Store nicht kostenlos",      // ProductNotFree
    "Kostenloses Spiel. Drücken Sie Kreuz, um es zu Ihrem Konto hinzuzufügen und zu spielen",  // FreeAcquireHint
    "DNS-Auflösung für Microsoft-Server fehlgeschlagen. Stelle auf der PS5 sicher, dass NanoDNS läuft und der primäre DNS auf die lokale IP gesetzt ist, um Internetzugriff zu behalten.", // DnsBlockedNanoDns
    "Dieses Microsoft-Konto hat noch kein Xbox-Profil. Melde dich auf xbox.com auf dem Smartphone oder PC an, um deinen Gamertag zu erstellen, und versuche es erneut.", // XboxProfileMissing
    "Warteschlange bereit! Spiel wird gestartet...",  // QueueReadyAlert
    "Signalton bei Warteschlangenende",               // QueueReadyNotification
    "Gespielt: %s",                                   // PlaytimePlayed
    "Aktualisieren",                                  // RefreshLibrary
    "Bibliothek wird aktualisiert...",                // RefreshingLibrary
    "Dieses Xbox-Konto ist gesperrt oder gebannt. Details unter enforcement.xbox.com.", // XboxAccountBanned
    "Xbox Live wird im Land oder in der Region dieses Kontos nicht angeboten.", // XboxRegionNotSupported
    "Altersprüfung oder Zustimmung zu den Bedingungen erforderlich. Melde dich im Browser auf xbox.com an und versuche es erneut.", // XboxAdultVerificationRequired
    "Kinderkonto: Ein Erwachsener muss dieses Konto unter account.microsoft.com/family zu einer Microsoft-Familie hinzufügen.", // XboxChildAccountFamily
    "Anmeldung prüfen",                               // CheckSignIn
    "Prüfen",                                         // RunCheck
    "Netzwerktest",                                   // NetworkTest
    "Testen",                                         // RunTest
    "Erfolge",                                        // Achievements
    "Keine Erfolge",                                  // NoAchievements
    "Gesperrt",                                       // AchievementLocked
    "Geheimer Erfolg",                                // SecretAchievement
    "Wunschliste",                                    // Wishlist
    "Zur Wunschliste hinzufügen",                     // AddWishlist
    "Von Wunschliste entfernen",                      // RemoveWishlist
    "Zur Wunschliste hinzugefügt",                    // AddedToWishlist
    "Von Wunschliste entfernt",                       // RemovedFromWishlist
    "%s ist im Angebot!",                             // WishlistOnSale
    "%s ist jetzt im Game Pass!",                     // WishlistInGamePass
    "Projekt unterstützen",                           // SupportProject
    "PBOX-Entwicklung unterstützen",                 // SupportTitle
    "PBOX ist ein Open-Source-Projekt, das mit viel Engagement entwickelt wird, um das beste Xbox Cloud Gaming-Erlebnis auf die PlayStation 5 zu bringen. Wenn dir die App gefällt und du die Weiterentwicklung unterstützen möchtest, spendiere mir gerne einen Kaffee auf Ko-Fi!", // SupportMessage
    "Ko-fi",                                          // SupportKoFi
    "Mit dem Smartphone scannen",                     // ScanToDonate
    "Ton testen",                                     // TestSound
    "Wunschliste ist leer",                           // WishlistEmpty
    // Loading tips
    "Touchpad: ↓ wischen (oder Touchpad + Options) für das Menü, ↑ für die Xbox-Taste", // TipTouchpadMenu
    "USB-Tastatur und -Maus an der Konsole werden in unterstützten Cloud-Spielen unterstützt", // TipKeyboardMouse
    "Kostenlose Spiele, Demos und Store-Angebote direkt in der App-Bibliothek sichern", // TipFreeStore
    "Problem aufgetreten? Öffnen Sie 'Problem melden', um einen QR-Code mit Konsolenprotokollen zu scannen", // TipBugReportQr
    "Gefällt Ihnen das Projekt? Unterstützen Sie die Weiterentwicklung via Ko-fi in den Einstellungen!", // TipSupportKofi
    "120-Hz-Videoausgabe in den Einstellungen für geringere Anzeigelatenz und flüssigere Steuerung aktivieren", // Tip120HzVideo
    "Stick-Totzone in den Einstellungen kalibrieren, um Stick-Drift zu verhindern und Präzision zu verbessern", // TipAnalogDeadzone
    "Integriertes DualSense-Mikrofon für Party- und Multiplayer-Sprachchat verwenden", // TipDualSenseMic
    "In Spielen mit Mausunterstützung das DualSense-Touchpad als Mauszeiger verwenden", // TipTouchpadMouse
    "Gyroskop-Zielen in den Einstellungen aktivieren, um mit Bewegungssensoren präzise zu zielen", // TipGyroAiming
    "AMD FSR-Upscaling und Schärfefilter verbessern Bildschärfe und Details beim Streaming", // TipFSRUpscaling
    "Streaming-Bitrate in den Einstellungen auf bis zu 45 Mbit/s für maximale Qualität anpassen", // TipCustomBitrate
    "Xbox-Erfolge werden beim Spielen automatisch als native PlayStation 5-Trophäen freigeschaltet", // TipNativeTrophies
    "Trophäen-Tracking für einzelne Spiele direkt auf der Spieledetailseite ein- oder ausschalten", // TipPerGameTrophies
    "Öffnen Sie http://[konsolen-ip]:8080 im Browser für Zugriff auf die SmartGlass WebUI", // TipSmartGlassWebUI
    "Kostenlose Spiele und Demos mit nur einem Klick direkt in der Anwendung sichern", // TipClaimFreeStore
    "Tastenbelegung für jedes Spiel individuell im Einstellungsmenü anpassen", // TipButtonRemap
    "Ihre Spielebibliothek lädt sofort aus dem lokalen Cache ohne Wartezeiten beim Start", // TipInstantResume
    "Beim Spielen auf dem Touchpad nach unten wischen, um Lautstärke und Bitrate anzupassen", // TipInGameMenu
    "Hintergrund-Delta-Sync hält Katalog und Regallisten automatisch auf dem neuesten Stand", // TipBackgroundSync
    // Settings descriptions
    "Ändert die Sprache der Benutzeroberfläche sowie die bevorzugte Audio- und Untertitelsprache in Cloud-Spielen", // SettingDescLanguage
    "Legt die maximale Streaming-Auflösung fest (1080p, 720p oder Beste). Wird beim nächsten Spielstart wirksam", // SettingDescResolution
    "Wählt die Microsoft-Rechenzentrumsregion für das Streaming aus (Automatisch oder bestimmte Regionen)", // SettingDescRegion
    "Passt die innere Totzone der DualSense-Analogsticks an, um Drift und unbeabsichtigte Bewegungen zu vermeiden", // SettingDescDeadzone
    "Aktiviert oder deaktiviert die Impuls-Trigger-Vibration an den adaptiven DualSense-Triggern L2 und R2", // SettingDescTriggerRumble
    "Wechselt die Tastenbelegung für Bestätigen und Zurück zwischen Kreuz (westlich) und Kreis (japanisch)", // SettingDescConfirmButton
    "Konfiguriert Farbe und Verhalten der Lichtleiste des DualSense-Controllers beim Navigieren und Spielen", // SettingDescLightBar
    "Prüft und installiert offizielle App-Updates automatisch direkt auf der Konsole ohne PC", // SettingDescUpdates
    "Ermöglicht die Xbox-Konto-Anmeldung über eine andere Region für alternative Spielkataloge", // SettingDescLoginCountry
    "Aktiviert 120-Hz-Videoausgabe auf Ihrer Konsole für minimale Eingabelatenz und höhere Bildwiederholrate", // SettingDescHighRefresh
    "Legt die maximale Bitrate für das Videostreaming fest, um Bildqualität zu optimieren oder Daten zu sparen", // SettingDescBitrateCap
    "Regelt die Gesamtlautstärke während der Spielsitzungen im Cloud-Streaming", // SettingDescGameVolume
    "Weist Tasten der USB- oder Bluetooth-Tastatur den entsprechenden Xbox-Controller-Tasten beim Spielen zu", // SettingDescKeyboardKeys
    "Wechselt zwischen Fenster- und Vollbildmodus auf unterstützten Desktop-Plattformen", // SettingDescDisplayMode
    "Öffnet den Test- und Kalibrierungsbildschirm für alle Tasten und Achsen des angeschlossenen Controllers", // SettingDescControllerButtons
    "Nutzt die DualSense-Bewegungssensoren zur Unterstützung des analogen Zielens in Shooter- und Actionspielen", // SettingDescGyro
    "Spielt einen Signalton ab, wenn die Wartezeit in der xCloud-Warteschlange endet und das Spiel bereit ist", // SettingDescQueueReady
    "Führt eine Diagnose der Xbox Live-Anmeldung durch und prüft Zugriffstoken, Profil und Abonnements", // SettingDescCheckSignIn
    "Misst Ping (RTT) und Jitter zu Cloud-Gaming-Rechenzentren in mehreren weltweiten Regionen", // SettingDescNetworkTest
    "Zeigt einen QR-Code, um den Entwickler via Ko-fi zu unterstützen und die Pflege des Projekts zu sichern", // SettingDescSupportProject
    "Neuigkeiten",                                    // WhatsNew
    "Neuigkeiten",                                    // WhatsNewTitle
    "Controller-Lautsprecher",                        // PadSpeakerVolume
    "Stumm",                                          // Mute
    "Web-Steuerung",                                  // WebControlTitle
    "Über Smartphone verbinden",                      // WebControlSubtitle
    "Mit demselben WLAN verbinden, um zu suchen, Tasten zu belegen, das Smartphone als Controller zu nutzen, Fehler zu melden oder Logs anzusehen.", // WebControlDesc
    "Videodekodierung",                               // VideoDecoder
    "Hardware (Empfohlen)",                           // VideoDecoderHw
    "Software (CPU)",                                 // VideoDecoderSw
    "Wählt Hardware-Dekodierung (libSceVideodec2 auf PS5, HWAccel auf Desktop) oder Software-Dekodierung (CPU)", // SettingDescVideoDecoder
    "Audio-zu-Haptik",                                // AudioHaptics
    "Wandelt tiefe Audiofrequenzen in DualSense-Haptik-Vibrationen um", // SettingDescAudioHaptics
    "Touchpad-Kurzbefehle",                           // TouchpadShortcuts
    "Konfiguriert Wischgesten sowie Links- und Rechtsklick auf dem DualSense-Touchpad", // SettingDescTouchpadShortcuts
    "Nach oben wischen (↑)",                          // TouchpadSwipeUp
    "Nach unten wischen (↓)",                         // TouchpadSwipeDown
    "Nach links wischen (←)",                         // TouchpadSwipeLeft
    "Nach rechts wischen (→)",                        // TouchpadSwipeRight
    "Linksklick",                                     // TouchpadClickLeft
    "Rechtsklick",                                    // TouchpadClickRight
    "Deaktiviert",                                    // TouchpadActNone
    "Spielmenü",                                      // TouchpadActGameMenu
    "Xbox-Taste",                                     // TouchpadActXboxButton
    "Statistiken umschalten",                         // TouchpadActToggleStats
    "Mikrofon stumm/aktiv",                           // TouchpadActToggleMic
    "Gyro-Modus wechseln",                            // TouchpadActCycleGyro
    "Trigger-Profil wechseln",                        // TouchpadActCycleTrigger
    "Touchpad + Options öffnet immer das Spielmenü",  // TouchpadHelp
    "Standardeinstellungen wiederherstellen",         // ResetSettings
    "Setzt alle Einstellungen auf die Werkseinstellungen zurück. 5 Sekunden ✕ gedrückt halten zur Bestätigung.", // SettingDescResetSettings
    "Einstellungen auf Standardwerte zurückgesetzt.", // SettingsResetNotice
    "Halten zum Zurücksetzen",                        // HoldToReset
    "Bibliothek ist bereits aktuell",                 // LibraryUpToDate
    "Bibliothek aktualisiert (%s neue Spiele)",       // LibraryUpdatedCount
    "Offline-Modus",                                  // OfflineMode
    "Preview-Funktionen (xCloud)",                    // PreviewFeatures
    "Aktiviert Preview-Client-Funktionen und werbefinanziertes Free-to-Play-Cloud-Streaming für Konten ohne Game Pass.", // SettingDescPreviewFeatures
    "Erfordert Xbox Game Pass Ultimate für Cloud-Streaming", // GamePassRequired
    "In Warteschlange (Wartezeit unbestimmt • wartet seit %s)", // InQueueIndeterminate
    "In Warteschlange (geschätzte Wartezeit: %s • wartet seit %s)", // InQueueEstimated
    "Um kostenlose Spiele außer Fortnite ohne Game Pass zu streamen, aktivieren Sie 'Preview-Funktionen' in den App-Einstellungen und auf xbox.com/play.", // F2pPreviewRequiredDesc
    "Dieses Konto muss 'Preview-Funktionen' im Profil auf xbox.com/play aktivieren, um werbefinanziertes Free-to-Play-Streaming freizuschalten.", // F2pPreviewAccountNeededDesc
    "Spieler",                                   // MenuPlayer
    "Ihre Xbox-Cloud-Spielzeit ist aufgebraucht, deshalb hat der Xbox-Dienst die Sitzung beendet. Seit November 2026 begrenzt Xbox das Cloud-Gaming pro Monat: 15 Std. mit Game Pass Ultimate, 10 Std. mit Premium und 5 Std. mit Essential. Mehr Zeit: Ihre Optionen finden Sie auf xbox.com, oder Sie warten auf die Stunden des nächsten Monats.", // CloudTimeUp
    "Die Sitzung wurde wegen Inaktivität beendet", // EndedIdle
    "%s verbleibend", // CloudTimeLeft
    "von %s", // CloudTimeOf
    "Unbegrenzte Cloud-Zeit", // CloudTimeUnlimited
    "Noch %s Xbox-Cloud-Spielzeit in diesem Monat", // CloudTimeWarn
    "Trophäen synchronisieren",                       // SyncTrophies
    "Synchronisiert alle Xbox-Erfolge Ihres Kontos und weist entsprechende Trophäen Ihrem PlayStation-Profil zu.", // SettingDescSyncTrophies
    "Sync",                                           // RunSyncTrophies
    "Synchronisierung abgeschlossen: %s Trophäe(n) in %s Titel(n) deinem Profil hinzugefügt!", // TrophiesSyncedToast
    "Trophäen-Warnung",                               // TrophiesDisclaimerTitle
    "Das Aktivieren der Trophäen-Konvertierung fügt Trophäen Ihrem PlayStation-Profil hinzu. Wenn Sie dieses Konto mit dem PlayStation Network verbinden, besteht Bann-Gefahr. Aktivieren Sie dies nur auf einem lokalen Profil oder wenn Sie sich nicht mehr mit dem PSN verbinden.", // TrophiesDisclaimerBody
    "Ich verstehe",                                   // TrophiesDisclaimerAware
    "Abbrechen",                                      // TrophiesDisclaimerCancel
    "Synchronisierte Trophäen entfernen",             // RemoveTrophies
    "Entfernt alle von PBOX hinzugefügten Trophäen aus diesem lokalen Profil, um ein PSN-Bannrisiko auszuschließen. Sie können sie jederzeit wieder über Ihr Xbox-Konto synchronisieren.", // SettingDescRemoveTrophies
    "Synchronisierte Trophäen entfernen?",            // RemoveTrophiesConfirmTitle
    "Dies löscht die lokalen Trophäenpakete von PBOX für dieses Profil. Ihre Erfolge bleiben auf Ihrem Microsoft/Xbox-Konto sicher gespeichert.", // RemoveTrophiesConfirmBody
    "Entfernen",                                      // RemoveTrophiesConfirm
    "%s Trophäen-Titel aus diesem Profil entfernt.",  // TrophiesRemovedToast
    "Erfolge werden synchronisiert...",               // SyncingTrophies
};
